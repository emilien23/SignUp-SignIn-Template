package com.example.authorizationtemplate.data.network.auth;

import android.support.annotation.Nullable;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Connection;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

import static org.mockito.Mockito.verify;


@RunWith(MockitoJUnitRunner.class)
public class AuthInterceptorTest {

    @Mock
    private AuthHolder authHolder;

    private AuthInterceptor authInterceptor;

    @Before
    public void setUp() {
        authInterceptor = new AuthInterceptor(authHolder);
    }

    @Test
    public void testSubscribe() {
        verify(authHolder).subscribeToSessionExpired((SessionListener)authRepository);
    }

    class MockChain implements Interceptor.Chain{

        @Override
        public Request request() {
            return null;
        }

        @Override
        public Response proceed(Request request) throws IOException {
            return null;
        }

        @javax.annotation.Nullable
        @Override
        public Connection connection() {
            return null;
        }

        @Override
        public Call call() {
            return null;
        }

        @Override
        public int connectTimeoutMillis() {
            return 0;
        }

        @Override
        public Interceptor.Chain withConnectTimeout(int timeout, TimeUnit unit) {
            return null;
        }

        @Override
        public int readTimeoutMillis() {
            return 0;
        }

        @Override
        public Interceptor.Chain withReadTimeout(int timeout, TimeUnit unit) {
            return null;
        }

        @Override
        public int writeTimeoutMillis() {
            return 0;
        }

        @Override
        public Interceptor.Chain withWriteTimeout(int timeout, TimeUnit unit) {
            return null;
        }
    }
}
