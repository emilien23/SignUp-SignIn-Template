package com.example.authorizationtemplate.utils.resolution;

public interface NetworkConnectivityResolution {

    void onConnectivityUnavailable();
}
