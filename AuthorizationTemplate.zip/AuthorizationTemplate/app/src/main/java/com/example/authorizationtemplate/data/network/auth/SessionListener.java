package com.example.authorizationtemplate.data.network.auth;

public interface SessionListener {
    void sessionExpired();
}
