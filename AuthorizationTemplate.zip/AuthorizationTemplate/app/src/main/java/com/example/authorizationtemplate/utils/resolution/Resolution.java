package com.example.authorizationtemplate.utils.resolution;


public interface Resolution extends NetworkConnectivityResolution, HttpResolution {}





