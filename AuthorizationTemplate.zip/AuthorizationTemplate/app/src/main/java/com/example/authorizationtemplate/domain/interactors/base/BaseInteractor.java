package com.example.authorizationtemplate.domain.interactors.base;

public interface BaseInteractor {
    void unsubscribe();
}
