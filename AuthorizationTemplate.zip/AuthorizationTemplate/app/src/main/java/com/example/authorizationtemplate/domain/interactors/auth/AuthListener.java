package com.example.authorizationtemplate.domain.interactors.auth;

public interface AuthListener {
    void onUnauthorized();
}
