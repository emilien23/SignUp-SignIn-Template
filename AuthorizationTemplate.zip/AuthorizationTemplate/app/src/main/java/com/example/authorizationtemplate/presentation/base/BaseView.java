package com.example.authorizationtemplate.presentation.base;

public interface BaseView {
}
